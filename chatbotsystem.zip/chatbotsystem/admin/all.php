<br>
	<link rel="stylesheet" type="text/css" href="css/animate.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/responsive-tabs.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/global.css" media="all" /> 
	<link rel="stylesheet" type="text/css" href="style2.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all" />
	
	
	<script src="js/jquery.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/responsive-tabs.js"></script>
	<script type="text/javascript" src="js/vertical-tab.js"></script>
	<script type="text/javascript" src="js/animations.min.js"></script>
</br>