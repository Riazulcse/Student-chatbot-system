<!-- <br>
<h4><strong><center>MAWLANA BHASHANI SCIENCE AND TECHNOLOGY UNIVERSITY</center></strong></h4> -->
              
<?php include('news.php'); ?>
<br><br>
 <!-- <div class="large-4 columns extra-padding">		 
		<div class="winbox-blue text-center ">
			<?php
			  $day=date("dS");
			  $dd=date("l");
			  $mm=date("F");
			  $yy=date("Y");
			?>
			<h4 class="text-left" style="color:#fff;"><i class="fi fi-calendar"></i> <?php echo $dd;?></h4><br />
			<span style="font-size:6em;font-family:'sans serif',arial;"><?php echo $day;?>
			</span>
			<br/><br />
			<span style="font-size:2em;font-family:'sans serif',arial;"><?php echo $mm ." ".$yy ;?></span>
			   
		</div>
	  </div>
	  
	  <div class="large-4 columns extra-padding">		 
		<div class="winbox-green text-center">
	
			<h4 class="text-left" style="color:#fff"><i class="fi fi-info"></i> About</h4>

          <br />
		
			   
		</div>
	  </div>
	  
	  <div class="large-4 columns extra-padding">		 
		<div class="winbox-voilet text-center">
			
			<h4 class="text-left" style="color:#fff"><i class="fi fi-link"></i> Necessary Links</h4>
            
			
	    <div  data-anim-type="zoomIn" data-anim-delay="500">
        <br />
		
<style>
.table{
	color:#FFF;
	font-size:16px;
}
.table:hover{
	color: #C00;
	font:bold;
}
.sa2{
	border-radius:8px;
}
	</style>
        
                  
				</div>
   
		</div>
	  </div>
</div>



 -->