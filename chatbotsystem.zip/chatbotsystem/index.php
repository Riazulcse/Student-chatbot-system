<!DOCTYPE html>
<html>
<head>
 
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>Welcome to CSE</title>

 <!-- CSS -->
 <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
 <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
 <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
 <link rel="stylesheet" href="assets/css/form-elements.css">
 <link rel="stylesheet" href="assets/css/style.css">
 <link rel="shortcut icon" href="assets/ico/mbstu.ico">


 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body><br><br><br><br>
  <style>
  div.a {
    text-align: center;
  }
  </style>
  <div class="a">
    <h1 class="text-white text-center">WELCOME TO CHATBOT SYSTEM</h1><br><br>
    <h3 class="text-white text center">Please Signup/Login</h3>

    <br><br>

    <div class="center"></div>  
    <div class="dropdown">
      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
       Admin Signup&Login
     </button>
     <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item" href="admin/admin_signup.php"><h2>Admin Signup</h2></a>
      <a class="dropdown-item" href="admin/admin_login.php"><h2>Admin Login</h2></a>
      
        
  </div><br><br><br><br><br><br><br>
  <div class="center"></div>  
    <div class="dropdown">
      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
       User Signup&Login
     </button>
     <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      
      <a class="dropdown-item" href="student_signup.php"><h2>Student Signup</h2></a>
      <a class="dropdown-item" href="student_login.php"><h2>Student Login</h2></a>
    </div>
    
  </div>
</div>
<style type="text/css">
div.dropdownMenuButton {
  text-align: center;
}

.dropdown {
  text-align:center;
}

.dropdown-menu {
  text-align: center;
}
</style>
</div>

<style>
.new{
  color:#090;
}
.new:hover{
  color:#0F0;
}
</style>

<br><br><br><br><br><br><br><br>

<style>
div.description {
  text-align: center;
}
</style>
<br><br><br><br><br><br><br><br><br><br><br><br>
<div class="description">
  <p>
    <h4 class="text-white text center">Developed By: STUDENT Of CSE, MBSTU</h4>
    
  </p>
</div>



<!-- Javascript -->
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>         
<script src="bundles/modernizr8fce?v=wBEWDufH_8Md-Pbioxomt90vm6tJN2Pyy9u9zHtWsPo1"></script>
<script src="bundles/scriptsd83f?v=oz581ohlwKFbCRbNAxF4puJyoDQTyWRyWqNWcC00WVw1"></script>
<script defer src="StartJS/Circliful.js"></script>
<script src="assets/js/jquery.backstretch.min.js"></script>
<script src="assets/js/scripts.js"></script>

</body>
</html>