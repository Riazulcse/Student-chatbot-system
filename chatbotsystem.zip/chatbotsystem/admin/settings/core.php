<?php
require('dbsettings.php');
?>
