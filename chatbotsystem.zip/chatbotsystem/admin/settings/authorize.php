<?php

if(!isset($_SESSION['openpluslogged'])){
 header('Location:index.php');
		die();
}
?>
