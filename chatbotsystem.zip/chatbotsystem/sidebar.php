
<dl class="accordion text-center">
  <dd>
    <img src="assets/ico/logo1.png"  height="305" width="307" vspace="5" alt="User Image"/>
  </dd>
  
  <dd>
    <a href="dashboard.php" style="background:#3EB05B;"  title="Dashboard Home"><i class="fa fa-home sancolor-white"></i></a>
  </dd>
  
  <!--  <dd>
    <a href="dashboard.php?page=profile"  style="background:#0099D3;"  title="Profile"><i class="fi fi-torso"></i></a>
  </dd>
  
   -->
  <dd>
  <a href="dashboard.php?page=updateprofile" style="background:#F7990D"  title="Profile Update"><i class="fa fa-user" aria-hidden="true"></i></a>
  </dd>
   <!-- <dd>
  <a href="dashboard.php?page=addquestions" style="background:#F7990D"  title="Add Question"><i class="fa fa-plus" aria-hidden="true"></i></a>
  </dd> -->

<dd>
    <a href="dashboard.php?page=chatbot" style="background:#3EB05B;"  title="Chatbot"><i class="fa fa-comments-o sancolor-white"></i></a>
  </dd>
</dl>
